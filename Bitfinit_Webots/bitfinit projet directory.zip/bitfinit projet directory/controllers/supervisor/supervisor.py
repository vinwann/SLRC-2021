"""Supervisor controller."""

from controller import Supervisor,Node

sup = Supervisor()

timestep = int(sup.getBasicTimeStep())

slave = sup.getFromDef("Supervisor")
master = sup.getFromDef("Robot_A") #robot name

max = 0
while sup.step(timestep) != -1:
    v_data = master.getVelocity()
    x,z = v_data[0],v_data[2]
    v = round(((x**2 + z**2)**0.5)*100,3)
    if max < v:
        max = v
    #print("-----------------------------------------------------------------")
    #print("Robot's speed: {:.2f} cms-1".format(v),"  |   Robot's maximum speed: {:.2f} cms-1".format(max))
    #print("-----------------------------------------------------------------")
